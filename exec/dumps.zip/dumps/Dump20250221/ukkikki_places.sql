-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: i12c204.p.ssafy.io    Database: ukkikki
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `places`
--

DROP TABLE IF EXISTS `places`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `places` (
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `place_id` int(11) NOT NULL AUTO_INCREMENT,
  `travel_plan_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  PRIMARY KEY (`place_id`),
  KEY `FK59dyexv2ra8bo3molpush73py` (`travel_plan_id`),
  CONSTRAINT `FK59dyexv2ra8bo3molpush73py` FOREIGN KEY (`travel_plan_id`) REFERENCES `travel_plans` (`travel_plan_id`)
) ENGINE=InnoDB AUTO_INCREMENT=264 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `places`
--

LOCK TABLES `places` WRITE;
/*!40000 ALTER TABLE `places` DISABLE KEYS */;
INSERT INTO `places` VALUES (40.7098774,-73.9625052,234,104,'피터 루거 스테이크 하우스','178 Broadway, Brooklyn, NY 11211 미국'),(40.7466662,-73.9819629,235,104,'울프강 스테이크','4 Park Ave, New York, NY 10016 미국'),(40.7507861,-73.9864611,236,104,'킨스 스테이크하우스','72 W 36th St., New York, NY 10018 미국'),(48.8531827,2.3691443,237,110,'바스티유 광장','Pl. de la Bastille, 75004 Paris, 프랑스'),(48.8282797,2.4330972,238,110,'방쎈느 산림공원','Rte de la Pyramide, 75012 Paris, 프랑스'),(48.8938489,2.39026,239,110,'라빌레트 공원','211 Av. Jean Jaurès, 75019 Paris, 프랑스'),(48.94112819999999,2.3190835,240,110,'셩뜨헨느 공원','46 Av. Georges Pompidou, 92390 Villeneuve-la-Garenne, 프랑스'),(48.8338325,2.3324222,241,110,'파리 지하납골당','1 Av. du Colonel Henri Rol-Tanguy, 75014 Paris, 프랑스'),(41.3852706,2.1809472,242,110,'피카소 미술관','Carrer de Montcada, 15-23, Ciutat Vella, 08003 Barcelona, 스페인'),(48.8606111,2.337644,243,110,'루브르 박물관','프랑스 75001 파리'),(35.7188351,139.7765215,244,108,'도쿄 국립박물관','13-9 Uenokōen, Taito City, Tokyo 110-8712 일본'),(35.652129,139.726474,245,108,'도쿄 도립 중앙 도서관','5-chōme-7-13 Minamiazabu, Minato City, Tokyo 106-8575 일본'),(35.7155722,139.5125434,246,108,'에도도쿄건축정원','일본 〒184-0005 Tokyo, Koganei, Sakurachō, 3-chōme−7−１ 内 都立小金井公園'),(35.76938030000001,139.4403147,247,108,'세이부엔 유원지','2964 Yamaguchi, Tokorozawa, Saitama 359-1145 일본'),(35.77595419999999,139.4052646,248,108,'사야마 호수','12 Shōrakuji, Tokorozawa, Saitama 359-1154 일본'),(33.5862065,130.3764646,249,116,'오호리 공원','일본 〒810-0051 Fukuoka, Chuo Ward, Ōhorikōen, 1 公園管理事務所'),(33.5897944,130.4111028,250,116,'캐널시티 하카타','1-chōme-2-2 Sumiyoshi, Hakata Ward, Fukuoka, 812-0018 일본'),(33.5932846,130.35151,251,116,'후쿠오카타워','2-chōme-3-26 Momochihama, Sawara Ward, Fukuoka, 814-0001 일본'),(34.761491,135.6525217,252,119,'네야가야 공원','1707 Neyagawakōen, Neyagawa, Osaka 572-0854 일본'),(34.76276420000001,135.714264,253,119,'쿠론도 연못 자연공원','5035 Takayamachō, Ikoma, Nara 630-0101 일본'),(34.8109359,135.5059153,254,119,'센리중앙공원','일본 〒560-0082 大阪府豊中市新千里東町３丁目９'),(35.4554755,139.6388669,255,119,'컵 누들 박물관 요코하마','2-chōme-3-4 Shinkō, Naka Ward, Yokohama, Kanagawa 231-0001 일본'),(26.1344994,127.7913368,256,121,'미바루 해변','Hyakuna-1599-6 Tamagusuku, Nanjo, Okinawa 901-0603 일본'),(26.1400781,127.7960217,257,121,'하마가와 우타키','Hyakuna-707 Tamagusuku, Nanjo, Okinawa 901-0603 일본'),(26.1335308,127.7846459,258,121,'하마베노차야','일본 〒901-0604 Okinawa, Nanjo, Tamagusuku, Tamagusuku−２−１'),(26.1417989,127.7955259,259,121,'카페 야부사치','Hyakuna-646-1 Tamagusuku, Nanjo, Okinawa 901-0603 일본'),(40.4319077,116.5703749,260,122,'만리장성','중국 베이징 시 화이러우 구 邮政编码: 101406'),(39.9168038,116.3971621,261,122,'자금성','4 Jing Shan Qian Jie, Dong Cheng Qu, Bei Jing Shi, 중국 100009'),(40.0798573,116.6031121,262,122,'베이징 서우두 국제공항','중국 베이징 시 순이 구 3JH3+W6X'),(39.9504553,116.4671995,263,122,'포시즌스 호텔 베이징','48 Liang Ma Qiao Lu, Chao Yang Qu, Bei Jing Shi, 중국 100125');
/*!40000 ALTER TABLE `places` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21 10:13:31
