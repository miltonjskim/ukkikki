-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: i12c204.p.ssafy.io    Database: ukkikki
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `airports`
--

DROP TABLE IF EXISTS `airports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `airports` (
  `city_id` int(11) DEFAULT NULL,
  `airport_name` varchar(20) NOT NULL,
  `airport_code` varchar(255) NOT NULL,
  PRIMARY KEY (`airport_code`),
  KEY `FKo1ddf0ullcf8qfgsf1b2nomed` (`city_id`),
  CONSTRAINT `FKo1ddf0ullcf8qfgsf1b2nomed` FOREIGN KEY (`city_id`) REFERENCES `cities` (`city_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `airports`
--

LOCK TABLES `airports` WRITE;
/*!40000 ALTER TABLE `airports` DISABLE KEYS */;
INSERT INTO `airports` VALUES (47,'아디스아바바 볼레','ADD'),(51,'오클랜드','AKL'),(55,'팔레올로','APW'),(25,'수완나품 국제공항','BKK'),(41,'엘도라도','BOG'),(45,'카이로','CAI'),(21,'광저우 바이윈 국제공항','CAN'),(4,'샤를드골 국제공항','CDG'),(52,'크라이스트처치','CHC'),(7,'제주 국제공항','CJU'),(44,'케이프타운','CPT'),(12,'신치토세 공항','CTS'),(33,'칸쿤 국제공항','CUN'),(3,'뉴어크 자유 국제공항','EWR'),(39,'미니스트로 피스타리니','EZE'),(11,'후쿠오카 공항','FUK'),(34,'과다할라 국제공항','GDL'),(5,'리우 데 자네루 국제공항','GIG'),(8,'김포 국제공항','GMP'),(28,'노이바이 국제공항','HAN'),(35,'호세 마르티 국제공항','HAV'),(22,'홍콩 국제공항','HKG'),(26,'푸켓 국제공항','HKT'),(2,'하네다 국제공항','HND'),(16,'다니엘 K. 이노우에 국제공항','HNL'),(1,'인천 국제공항','ICN'),(3,'존.F.케네디 국제공항','JFK'),(43,'O.R. 탐보','JNB'),(10,'간사이 국제공항','KIX'),(14,'로스앤젤레스 국제공항','LAX'),(3,'라과디아 공항','LGA'),(42,'호르헤 차베스','LIM'),(48,'무르탈라 모하메드','LOS'),(50,'멜버른','MEL'),(32,'멕시코시티 국제공항','MEX'),(53,'난디','NAN'),(46,'조모 케냐타','NBO'),(2,'나리타 국제공항','NRT'),(13,'나하 공항','OKA'),(12,'삿포로 오카다마 공항','OKD'),(18,'시카고 오헤어 국제공항','ORD'),(4,'오를리 국제공항','ORY'),(19,'베이징 서우두 국제공항','PEK'),(54,'잭슨스','POM'),(37,'푸타 카나 국제공항','PUJ'),(6,'김해 국제공항','PUS'),(20,'상하이 푸둥 국제공항','PVG'),(40,'코모도로 아르투로 메리노 베니테스','SCL'),(5,'산투스 두몽 공항','SDU'),(17,'시애틀 타코마 국제공항','SEA'),(15,'샌프란시스코 국제공항','SFO'),(27,'떤선녓 국제공항','SGN'),(38,'산토도밍고 라스아메리카스 국제공항','SQD'),(49,'시드니 킹스포드 스미스','SYD'),(23,'타오위안 국제공항','TPE'),(36,'후안 고알베르토 고메즈 국제공항','VRA'),(31,'몬트리올 트뤼도 국제공항','YUL'),(30,'벤쿠버 국제공항','YVR'),(29,'토론토 피어슨 국제공항','YYZ');
/*!40000 ALTER TABLE `airports` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21 10:13:27
