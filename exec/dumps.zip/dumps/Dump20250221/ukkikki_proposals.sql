-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: i12c204.p.ssafy.io    Database: ukkikki
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `proposals`
--

DROP TABLE IF EXISTS `proposals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proposals` (
  `company_id` int(11) DEFAULT NULL,
  `deposit` int(11) NOT NULL,
  `end_date` date NOT NULL,
  `guide_included` bit(1) NOT NULL,
  `insurance_included` bit(1) NOT NULL,
  `min_people` int(11) NOT NULL,
  `proposal_id` int(11) NOT NULL AUTO_INCREMENT,
  `start_date` date NOT NULL,
  `travel_plan_id` int(11) DEFAULT NULL,
  `create_time` datetime(6) NOT NULL,
  `end_date_arrival_time` datetime(6) NOT NULL,
  `end_date_boarding_time` datetime(6) NOT NULL,
  `start_date_arrival_time` datetime(6) NOT NULL,
  `start_date_boarding_time` datetime(6) NOT NULL,
  `update_time` datetime(6) DEFAULT NULL,
  `name` varchar(20) NOT NULL,
  `airline` varchar(50) NOT NULL,
  `product_introduction` varchar(4000) NOT NULL,
  `refund_policy` varchar(4000) NOT NULL,
  `arrival_airport_code` varchar(255) DEFAULT NULL,
  `departure_airport_code` varchar(255) DEFAULT NULL,
  `proposal_status` enum('A','D','V','W') NOT NULL,
  PRIMARY KEY (`proposal_id`),
  KEY `FK2lfmg5oapln6mjnj5b2cyajtg` (`departure_airport_code`),
  KEY `FK3vccu1dc8jukc6hy29d3teo8u` (`company_id`),
  KEY `FKacy0gdxkvvji4l0r551jfx4f5` (`arrival_airport_code`),
  KEY `FKbf2l1s34y0dbsqdbhulk3yxsk` (`travel_plan_id`),
  CONSTRAINT `FK2lfmg5oapln6mjnj5b2cyajtg` FOREIGN KEY (`departure_airport_code`) REFERENCES `airports` (`airport_code`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK3vccu1dc8jukc6hy29d3teo8u` FOREIGN KEY (`company_id`) REFERENCES `companies` (`company_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FKacy0gdxkvvji4l0r551jfx4f5` FOREIGN KEY (`arrival_airport_code`) REFERENCES `airports` (`airport_code`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FKbf2l1s34y0dbsqdbhulk3yxsk` FOREIGN KEY (`travel_plan_id`) REFERENCES `travel_plans` (`travel_plan_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proposals`
--

LOCK TABLES `proposals` WRITE;
/*!40000 ALTER TABLE `proposals` DISABLE KEYS */;
INSERT INTO `proposals` VALUES (16,500000,'2025-04-09',_binary '',_binary '',5,141,'2025-04-05',119,'2025-02-21 09:42:43.792426','2025-02-21 09:50:00.000000','2025-02-25 00:00:00.000000','2025-02-21 11:10:00.000000','2025-02-22 09:45:00.000000','2025-02-21 09:42:43.788179','벚꽃보러 오사카가카','대한항공','오사카, 맛과 멋의 도시로 떠나는 특별한 여행  오사카는 일본의 전통과 현대가 어우러진 도시로, 활기찬 거리 문화와 다채로운 미식 경험이 기다리고 있습니다. 본 상품은 오사카의 대표 관광지와 숨은 명소를 체험할 수 있도록 구성되어 있습니다.  숙박: 오사카 시내 중심에 위치한 현대적인 호텔에서의 편안한 숙박 제공 식사: 현지 인기 음식인 오코노미야키, 다코야키 등 다양한 맛집 탐방 관광: 오사카 성, 도톤보리, 신세카이 등 주요 명소 입장권 및 현지 투어 포함 현지 가이드: 전문 현지 가이드와 함께하는 깊이 있는 문화 해설 및 맞춤형 추천 가족, 친구, 연인 모두에게 적합한 맞춤형 일정으로, 오사카의 매력을 한껏 느낄 수 있는 특별한 여행을 경험해보세요.','취소 가능 기간: 여행 출발 30일 전까지는 무료 취소가 가능합니다.  취소 수수료:  출발 29일~15일 전 취소 시: 총 예약 금액의 20% 출발 14일 전 이후 취소 시: 총 예약 금액의 50% 환불 처리: 취소 신청 접수 후 10 영업일 이내에 환불 처리가 완료됩니다.  불가 취소 조건: 예약 확정 후 여행 시작 전날 12시 이후 취소는 불가하며, 일부 특별 프로모션 상품은 환불이 불가한 조건이 적용될 수 있습니다.  일정 변경: 일정 변경이나 연기는 취소 수수료 없이 진행 가능하나, 변경된 일정에 따라 추가 비용이 발생할 수 있습니다.  상기 정책은 여행사 및 현지 사정에 따라 사전 안내 없이 변경될 수 있으므로, 예약 전 반드시 확인해주시기 바랍니다.','KIX','ICN','W'),(19,100000,'2025-03-07',_binary '',_binary '',6,142,'2025-03-03',118,'2025-02-21 09:49:14.498663','2025-03-07 12:15:00.000000','2025-03-07 09:40:00.000000','2025-02-21 12:20:00.000000','2025-03-03 09:35:00.000000','2025-02-21 09:49:14.494896','대만 야시장 식도락 여행!!','대한항공','대만 야시장 투어(현지인 강추픽)','예약- 여행 출발 14일 전: 전액 환불       - 여행 출발 7일 전: 50% 환불    ','TPE','ICN','W'),(17,2000000,'2025-02-26',_binary '',_binary '',5,143,'2025-02-21',121,'2025-02-21 09:50:17.586991','2025-02-26 11:00:00.000000','2025-02-26 09:55:00.000000','2025-02-21 11:00:00.000000','2025-02-21 09:40:00.000000','2025-02-21 09:50:17.583262','오키나와 스노클링 & 다이빙 여행','대한항공','오키나와 야외 액티비티 상품','7일 이내 환불은 불가능합니다.','OKA','ICN','W'),(19,500000,'2025-03-01',_binary '',_binary '',6,144,'2025-02-26',120,'2025-02-21 10:05:58.024308','2025-03-02 00:00:00.000000','2025-03-01 00:00:00.000000','2025-02-27 00:00:00.000000','2025-02-26 00:00:00.000000','2025-02-21 10:05:58.020637','시드니로 떠나는 골프 투어','대한항공','시드니 투어! 저희가 모시겠습니다','예약금은 14일 이전 환불 요청이 있어야 가능합니다.','SYD','ICN','W');
/*!40000 ALTER TABLE `proposals` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21 10:13:25
