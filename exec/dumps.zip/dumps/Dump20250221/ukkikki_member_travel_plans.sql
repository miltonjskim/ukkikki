-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: i12c204.p.ssafy.io    Database: ukkikki
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member_travel_plans`
--

DROP TABLE IF EXISTS `member_travel_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_travel_plans` (
  `adult_count` int(11) NOT NULL,
  `child_count` int(11) NOT NULL,
  `exit_yn` bit(1) NOT NULL,
  `host_yn` bit(1) NOT NULL,
  `infant_count` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `travel_plan_id` int(11) NOT NULL,
  `exit_time` datetime(6) DEFAULT NULL,
  `first_join_time` datetime(6) NOT NULL,
  `last_join_time` datetime(6) NOT NULL,
  PRIMARY KEY (`member_id`,`travel_plan_id`),
  KEY `FKb5n7ov3yqsb2u4gv7vs49lkqj` (`travel_plan_id`),
  CONSTRAINT `FK6o34dckwwhwxixmtlx98pgyhx` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FKb5n7ov3yqsb2u4gv7vs49lkqj` FOREIGN KEY (`travel_plan_id`) REFERENCES `travel_plans` (`travel_plan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_travel_plans`
--

LOCK TABLES `member_travel_plans` WRITE;
/*!40000 ALTER TABLE `member_travel_plans` DISABLE KEYS */;
INSERT INTO `member_travel_plans` VALUES (1,0,_binary '\0',_binary '',0,44,103,NULL,'2025-02-21 03:51:11.581817','2025-02-21 03:51:11.581817'),(2,1,_binary '\0',_binary '',0,44,104,NULL,'2025-02-21 03:54:14.010358','2025-02-21 03:54:14.010358'),(3,0,_binary '\0',_binary '',0,44,118,NULL,'2025-02-21 09:31:45.690878','2025-02-21 09:31:45.690878'),(1,0,_binary '\0',_binary '\0',0,45,104,NULL,'2025-02-21 04:10:03.536797','2025-02-21 04:10:03.536797'),(3,0,_binary '\0',_binary '',0,45,107,NULL,'2025-02-21 04:09:18.788145','2025-02-21 04:09:18.788145'),(2,0,_binary '\0',_binary '',0,45,114,NULL,'2025-02-21 09:13:06.193693','2025-02-21 09:13:06.193693'),(2,1,_binary '\0',_binary '',0,45,120,NULL,'2025-02-21 09:40:07.273699','2025-02-21 09:40:07.273699'),(5,0,_binary '\0',_binary '',0,46,116,NULL,'2025-02-21 09:28:14.566245','2025-02-21 09:28:14.566245'),(6,0,_binary '\0',_binary '',0,46,121,NULL,'2025-02-21 09:40:37.043917','2025-02-21 09:40:37.043917'),(6,0,_binary '\0',_binary '',0,46,122,NULL,'2025-02-21 09:44:42.757266','2025-02-21 09:44:42.757266'),(5,0,_binary '\0',_binary '',0,46,123,NULL,'2025-02-21 10:10:22.279469','2025-02-21 10:10:22.279469'),(3,0,_binary '\0',_binary '\0',0,48,103,NULL,'2025-02-21 03:59:44.935207','2025-02-21 03:59:44.935207'),(2,0,_binary '\0',_binary '',0,48,105,NULL,'2025-02-21 03:59:15.908843','2025-02-21 03:59:15.908843'),(5,0,_binary '\0',_binary '',0,48,106,NULL,'2025-02-21 04:02:35.667166','2025-02-21 04:02:35.667166'),(3,0,_binary '\0',_binary '',0,48,115,NULL,'2025-02-21 09:20:39.629860','2025-02-21 09:20:39.629860'),(2,0,_binary '\0',_binary '',0,48,117,NULL,'2025-02-21 09:29:14.025374','2025-02-21 09:29:14.025374'),(1,0,_binary '\0',_binary '\0',0,52,103,NULL,'2025-02-21 07:51:51.537269','2025-02-21 07:51:51.537269'),(1,0,_binary '\0',_binary '\0',0,52,104,NULL,'2025-02-21 04:03:27.792312','2025-02-21 04:03:27.792312'),(2,0,_binary '\0',_binary '\0',0,53,103,NULL,'2025-02-21 09:21:11.334639','2025-02-21 09:21:11.334639'),(4,0,_binary '\0',_binary '',0,53,108,NULL,'2025-02-21 04:10:33.728845','2025-02-21 04:10:33.728845'),(7,0,_binary '\0',_binary '',0,53,119,NULL,'2025-02-21 09:32:05.247723','2025-02-21 09:32:05.247723');
/*!40000 ALTER TABLE `member_travel_plans` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21 10:13:25
