-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: i12c204.p.ssafy.io    Database: ukkikki
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `companies` (
  `company_id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` datetime(6) NOT NULL,
  `delete_time` datetime(6) NOT NULL,
  `phone_number` varchar(11) NOT NULL,
  `business_registration_number` varchar(12) NOT NULL,
  `ceo_name` varchar(20) NOT NULL,
  `company_name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(64) NOT NULL,
  `profile_image_url` varchar(2000) NOT NULL,
  PRIMARY KEY (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companies`
--

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (16,'2025-02-20 19:58:01.862393','2025-02-20 19:58:01.862393','01094323593','6462800299','하나투어','하나투어','hanatour@naver.com','$2a$10$W7b6TmKm5obqTXEt5BkVcef8QHzzUKQWQ/dmAUwA6Zyb91pNj1L3K',''),(17,'2025-02-21 03:43:04.144931','2025-02-21 03:43:04.144931','02123123','1058200617','김하나','하나투어','hanatour@hanatour.co.kr','$2a$10$8GNoQiLttYzJYcxBjGQWv.ejaWXTS2KEp9kx..ObGfz0r2GRV1rlK',''),(18,'2025-02-21 03:44:00.003773','2025-02-21 03:44:00.003773','020011001','1058200617','김철수','한진관광','hanjin@hanjin.co.kr','$2a$10$J0b41/KMZ1KeywoxvWNoXeVoBijUq4dxeM7zbeeEwsX8ZohKn3umC',''),(19,'2025-02-21 03:44:55.708489','2025-02-21 03:44:55.708489','026860863','1058200617','박노랑','노랑풍선','norang@ybtour.co.kr','$2a$10$BcfQBBY4drRmlgAeCya3GuxZJ3W8ho.px8XNgX4f5SU9LvNESFB/q',''),(20,'2025-02-21 03:47:09.917627','2025-02-21 03:47:09.917627','01055617043','1058726271','김박사','여행박사','tourbaksa@tourbaksa.co.kr','$2a$10$qr79dDODActTfVvHFr7ireg4Y5Vlp4R54NTjPUEwANgQs4mkgtPWC',''),(21,'2025-02-21 03:47:30.404717','2025-02-21 03:47:30.404717','027983408','1058200617','박모두','모두투어','modu@modu.co.kr','$2a$10$M.QPkgaAzDIJ7dfYxgqVV.Oc77cSgNOwcwg9LgjprS5f/zLW/CbrK',''),(22,'2025-02-21 03:47:49.651352','2025-02-21 03:47:49.651352','01055617043','1058726271','김롯데','롯데관광','lottetour@lottetour.co.kr','$2a$10$W7Kky7OtSCd9Vv22SrkFZuavLZZuf7kVHUq8SGZc5MTNZkuNceT/a',''),(23,'2025-02-21 03:48:21.521295','2025-02-21 03:48:21.521295','028378819','1058200617','마이리얼트립','마이리얼트립','myrealtrip@myrealtrip.com','$2a$10$dzz42qI6.gp4dwOH/SdNh.SKrXSQdNXC/0WeqXcA0yMSHC8HH4TJO','');
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21 10:13:24
