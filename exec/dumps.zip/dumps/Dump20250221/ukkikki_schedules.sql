-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: i12c204.p.ssafy.io    Database: ukkikki
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `schedules`
--

DROP TABLE IF EXISTS `schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedules` (
  `proposal_id` int(11) DEFAULT NULL,
  `schedule_id` int(11) NOT NULL AUTO_INCREMENT,
  `end_time` datetime(6) NOT NULL,
  `start_time` datetime(6) NOT NULL,
  `image_url` varchar(2000) DEFAULT NULL,
  `schedule_name` varchar(255) NOT NULL,
  `day_number` varchar(255) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  PRIMARY KEY (`schedule_id`),
  KEY `FKs3wgdv3naaidq0tl7gr9315sl` (`proposal_id`),
  CONSTRAINT `FKs3wgdv3naaidq0tl7gr9315sl` FOREIGN KEY (`proposal_id`) REFERENCES `proposals` (`proposal_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=170 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedules`
--

LOCK TABLES `schedules` WRITE;
/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;
INSERT INTO `schedules` VALUES (141,156,'2025-04-05 03:40:00.000000','2025-04-05 02:40:00.000000','https://maps.googleapis.com/maps/api/place/js/PhotoService.GetPhoto?1sAVzFdbnklpiIkIR8c-jFcruiVseiCk3z5tFFRcd8uUTn3xVOEgyhgI_rdQ0qresVsOun0N7CZBuHkaN9s2YD9xPBgHHsZoY2sqvkYaJ-7wut5xCxejSmT1S3ul8D-Y1fe-1a-wLcwSPOwjxiVPeGn7FUnv2AuubzVf1DnIFuZslvtB4weFBKlDTO0K2B&3u400&4u400&5m1&2e1&callback=none&r_url=https%3A%2F%2Fi12c204.p.ssafy.io&key=AIzaSyA65-6xQRDaRsSlCtCBnYWKzpz-9XeNcIs&token=43552','센리중앙공원','1',34.8109359,135.5059153),(141,157,'2025-04-05 08:42:00.000000','2025-04-05 06:42:00.000000','https://maps.googleapis.com/maps/api/place/js/PhotoService.GetPhoto?1sAVzFdbli6MPCF60mywemtINeRoS0hUg9qG4lUadWhV7TwCbspA0Vy5yBpO91CfgMijzhIhcUetzwXJ91ozEyhzivU84unbxFzlLZ55xPyw2kgceaaWNxg5dsXMcw2CnTQwBqZ0BndlwuBrJ-oogdNuMCRE8dgZnVtQs3t3t1FoENydHm-4SNcsXhuwxF&3u400&4u400&5m1&2e1&callback=none&r_url=https%3A%2F%2Fi12c204.p.ssafy.io&key=AIzaSyA65-6xQRDaRsSlCtCBnYWKzpz-9XeNcIs&token=105661','컵 누들 박물관 요코하마','1',35.4554755,139.6388669),(141,158,'2025-04-05 12:42:00.000000','2025-04-05 10:42:00.000000','https://maps.googleapis.com/maps/api/place/js/PhotoService.GetPhoto?1sAVzFdbkyZcCdcUWdHO_Km_zhtjaKJTM-F_-J7npRVYrwdfMxVwo8P_tY-jIDY6iXqC45hFcpEtvi7MkQMj9hMtsVZRB_V7SxkFci01jQY_pGFhhXuuDVd4rVNLg1OXgCfXM34Xz2oMXvhp-MoRsvJnHM1KrcCnz--A2Z-21pyS70g-xferrfET6cmSLD&3u400&4u400&5m1&2e1&callback=none&r_url=https%3A%2F%2Fi12c204.p.ssafy.io&key=AIzaSyA65-6xQRDaRsSlCtCBnYWKzpz-9XeNcIs&token=33302','쿠론도 연못 자연공원','1',34.76276420000001,135.714264),(142,163,'2025-03-03 01:44:00.000000','2025-03-03 00:43:00.000000','https://maps.googleapis.com/maps/api/place/js/PhotoService.GetPhoto?1sAVzFdbmyNVJO9eNPO-rxRBZ-eH7Ct7PUscQllFENVCp9Z5Q69qWA_tgMXhSCfNAUx_iljsPOBZGd9_fDZ3P0kgHJdfOik6VGQVqJKwIG04rTKor-rK-tHOKA_BadMa_4YLwsSWB8DTahmd0ClfSSeafSKEyRyHKGp4TI3rXnD4tXATcXwVkPDYClAM9E&3u400&4u400&5m1&2e1&callback=none&r_url=https%3A%2F%2Fi12c204.p.ssafy.io&key=AIzaSyA65-6xQRDaRsSlCtCBnYWKzpz-9XeNcIs&token=115281','루저우 시','1',28.8716999,105.44257),(142,164,'2025-03-04 02:45:00.000000','2025-03-04 01:30:00.000000','https://maps.googleapis.com/maps/api/place/js/PhotoService.GetPhoto?1sAVzFdbkEAjqw9WNNyd0NEMiMCStao-HhSxk64AzngxgBMZH0ECuI2m60JGrFZGUdg8pcdXEsCfC2mQ-nRRRmJaL2Rxq9-S-IqpX07njN7icuxovUo9PNw1GcVVzvOWBfqzc9pnrti042XkTFoamxPacQ0PZQS3ry5rJvzFEwjIJQDIN9axfwBkRcueaz&3u400&4u400&5m1&2e1&callback=none&r_url=https%3A%2F%2Fi12c204.p.ssafy.io&key=AIzaSyA65-6xQRDaRsSlCtCBnYWKzpz-9XeNcIs&token=2928','린지앙 야시장','2',25.0301412,121.5542672),(142,165,'2025-03-05 05:49:00.000000','2025-03-05 04:46:00.000000','https://maps.googleapis.com/maps/api/place/js/PhotoService.GetPhoto?1sAVzFdbl8Js9wBSVSN2l4JLSwSDKk6S9WATuBE5xyG8G2T6-Tna7ccejH8g3YsbdpTHuqrWQ1q2UsdxqAqhtkwZafliacK1yDP8f_rNY7fBOtKpIUZDoJFbH7F8p8-mmYiq09ZMURcorK2sCFMguwWUmIxxtN5Q3daQAiV2a_HZoxPNTvCsAsY64H3M99&3u400&4u400&5m1&2e1&callback=none&r_url=https%3A%2F%2Fi12c204.p.ssafy.io&key=AIzaSyA65-6xQRDaRsSlCtCBnYWKzpz-9XeNcIs&token=105200','동먼 시장','3',25.0346276,121.5267355),(142,166,'2025-03-06 02:45:00.000000','2025-03-06 01:31:00.000000','https://maps.googleapis.com/maps/api/place/js/PhotoService.GetPhoto?1sAVzFdblY8zPJdP6mwyH8uBoC50HutZQFdGf5th-bgh6VFo-lTTpwxfrhCga7DPvvehBeY8DZ8-YMiszDj-zzc1O1Htmu4wc3t-0pLPFidhx48Co5mcH3hdbICdnq1GTMmuHG6Q5o_4sD90dgr44e9-3K8zfJ2_aNpCT3KZ_grajnAkWsWCoZzsnRtLXA&3u400&4u400&5m1&2e1&callback=none&r_url=https%3A%2F%2Fi12c204.p.ssafy.io&key=AIzaSyA65-6xQRDaRsSlCtCBnYWKzpz-9XeNcIs&token=130338','랴오닝 야시장','4',25.0488683,121.5421769),(143,167,'2025-02-21 00:49:00.000000','2025-02-21 00:48:00.000000','https://maps.googleapis.com/maps/api/place/js/PhotoService.GetPhoto?1sAVzFdbl4n9qWYQeG_SSq058tPM3qBV7QS_dSF7Ff8AA9w2D6tU4xRGfvNzH6XbCMGznkyW5CII6pqWOhMUeOzWHQty6y1-kcmQbYs0Y2cafzlnTTpDkJj57_bQw0_TQ7Fy5hcE9sg6pyO3UtIMkEGrYEKGEKJeqWMLDxur3pZfcQMxG7KpbJv3JQaBho&3u400&4u400&5m1&2e1&callback=none&r_url=https%3A%2F%2Fi12c204.p.ssafy.io&key=AIzaSyA65-6xQRDaRsSlCtCBnYWKzpz-9XeNcIs&token=115531','하마가와 우타키','1',26.1400781,127.7960217),(144,168,'2025-02-26 04:06:00.000000','2025-02-26 02:05:00.000000','https://maps.googleapis.com/maps/api/place/js/PhotoService.GetPhoto?1sAVzFdbmTu7OrII9xsy08xG_pK1rnBzZaWP6rzXC8X3uGW_BPO0-DEJbUnyqm0ZMRHyj4luasUmmnsQY-KsKbapfOvrSFJlhOnZhbOcwgDAjpCulDdP0xdZoBFvbLmlH2Vp2TxUKZa6M4x16giVku-bu_vQ-UF0i5VhyMqpvxD6avTL74tEL5QRs53RbR&3u400&4u400&5m1&2e1&callback=none&r_url=https%3A%2F%2Fi12c204.p.ssafy.io&key=AIzaSyA65-6xQRDaRsSlCtCBnYWKzpz-9XeNcIs&token=13466','모스만 파크','1',-32.0151669,115.7664032),(144,169,'2025-02-27 06:04:00.000000','2025-02-27 05:04:00.000000','https://maps.googleapis.com/maps/api/place/js/PhotoService.GetPhoto?1sAVzFdbkJt0gADIjazGdvY_Kk-B0fGBzIQ8CjS0l9ru0p730A6XtMgtKmJJP0EBz8Z3SnHmTzMYb9egTAH9osLC4biILm-LFrv3KtibPfXGnZmxCaw65qfcyEUpPRNvvocYBgCk9wWNOh24NMEK1EOs014pSJLL-Dnn3w6y6YiAsppfx4y-3kMa3UlvVN&3u400&4u400&5m1&2e1&callback=none&r_url=https%3A%2F%2Fi12c204.p.ssafy.io&key=AIzaSyA65-6xQRDaRsSlCtCBnYWKzpz-9XeNcIs&token=38475','로즈 베이 리조트','2',12.9477278,100.8911861);
/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21 10:13:22
