-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: i12c204.p.ssafy.io    Database: ukkikki
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `travel_plans`
--

DROP TABLE IF EXISTS `travel_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `travel_plans` (
  `arrival_city_id` int(11) DEFAULT NULL,
  `departure_city_id` int(11) DEFAULT NULL,
  `end_date` date NOT NULL,
  `max_people` int(11) NOT NULL,
  `min_people` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `travel_plan_id` int(11) NOT NULL AUTO_INCREMENT,
  `close_time` datetime(6) DEFAULT NULL,
  `create_time` datetime(6) NOT NULL,
  `name` varchar(20) NOT NULL,
  `host_comment` varchar(1000) DEFAULT NULL,
  `planning_status` enum('BIDDING','BOOKING','CONFIRMED','IN_PROGRESS') NOT NULL,
  PRIMARY KEY (`travel_plan_id`),
  KEY `FK4uxu2lra0bxj3w02drohh7h09` (`departure_city_id`),
  KEY `FKrmabihuf8iphluf51w6f5c4pq` (`arrival_city_id`),
  CONSTRAINT `FK4uxu2lra0bxj3w02drohh7h09` FOREIGN KEY (`departure_city_id`) REFERENCES `cities` (`city_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FKrmabihuf8iphluf51w6f5c4pq` FOREIGN KEY (`arrival_city_id`) REFERENCES `cities` (`city_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travel_plans`
--

LOCK TABLES `travel_plans` WRITE;
/*!40000 ALTER TABLE `travel_plans` DISABLE KEYS */;
INSERT INTO `travel_plans` VALUES (2,1,'2025-03-22',10,5,'2025-03-18',103,NULL,'2025-02-21 03:51:11.572246','오타쿠들을 위한 애니메이션 성지 순례',NULL,'IN_PROGRESS'),(3,1,'2025-03-21',15,10,'2025-03-10',104,NULL,'2025-02-21 03:54:14.001057','뉴욕 3대 스테이크 하우스 탐방',NULL,'IN_PROGRESS'),(11,6,'2025-04-06',8,4,'2025-04-02',105,NULL,'2025-02-21 03:59:15.900959','MZ 따라잡기 후쿠오카 핫플 투어 ',NULL,'IN_PROGRESS'),(4,1,'2025-05-28',25,15,'2025-05-22',106,NULL,'2025-02-21 04:02:35.657761','빵지순례 근데 이제 인스타 감성인',NULL,'IN_PROGRESS'),(25,1,'2025-04-06',30,10,'2025-04-01',107,NULL,'2025-02-21 04:09:18.780237','1일 3마사지. 연체 동물 프로젝트',NULL,'IN_PROGRESS'),(2,1,'2025-02-27',20,2,'2025-02-25',108,NULL,'2025-02-21 04:10:33.717335','도쿄로 짧게 같이 여행가실분!',NULL,'IN_PROGRESS'),(4,1,'2025-03-12',16,6,'2025-03-09',110,NULL,'2025-02-21 04:18:33.717335','축덕들만 모여라!! 유럽 축구 투어~',NULL,'IN_PROGRESS'),(12,1,'2025-03-01',18,4,'2025-02-26',114,NULL,'2025-02-21 09:13:06.181723','삿포로로 떠나는 휴양 여행',NULL,'IN_PROGRESS'),(4,1,'2025-03-12',14,7,'2025-03-06',115,NULL,'2025-02-21 09:20:39.622712','프랑스 파리 가실 분들 모집합니다',NULL,'IN_PROGRESS'),(11,1,'2025-02-22',30,10,'2025-02-21',116,NULL,'2025-02-21 09:28:14.548958','후쿠오카 힐링 여행, 같이 가실 분?',NULL,'IN_PROGRESS'),(30,1,'2025-03-18',14,4,'2025-03-12',117,NULL,'2025-02-21 09:29:14.018226',' 벤쿠버로 떠나요~',NULL,'IN_PROGRESS'),(23,1,'2025-03-07',12,6,'2025-03-03',118,NULL,'2025-02-21 09:31:45.680851','대만 야시장 식도락 여행!!',NULL,'BIDDING'),(10,6,'2025-04-09',30,5,'2025-04-05',119,'2025-02-19 11:33:00.000000','2025-02-21 09:32:05.239033','벚꽃보러 오사카가카',NULL,'BIDDING'),(49,1,'2025-03-01',12,6,'2025-02-26',120,NULL,'2025-02-21 09:40:07.265286','시드니로 떠나는 골프 투어',NULL,'BIDDING'),(13,7,'2025-02-26',20,5,'2025-02-21',121,'2025-02-22 23:43:00.000000','2025-02-21 09:40:37.035461','오키나와 스노클링 & 다이빙 여행',NULL,'BIDDING'),(19,6,'2025-02-25',10,5,'2025-02-24',122,'2025-02-22 09:48:00.000000','2025-02-21 09:44:42.749662','자금성부터 만리장성까지 역사 투어',NULL,'IN_PROGRESS'),(10,1,'2025-02-25',20,10,'2025-02-21',123,NULL,'2025-02-21 10:10:22.271163','오사카 힐링 여행, 함께 떠나요',NULL,'IN_PROGRESS');
/*!40000 ALTER TABLE `travel_plans` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21 10:13:23
