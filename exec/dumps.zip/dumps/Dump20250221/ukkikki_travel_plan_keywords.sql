-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: i12c204.p.ssafy.io    Database: ukkikki
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `travel_plan_keywords`
--

DROP TABLE IF EXISTS `travel_plan_keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `travel_plan_keywords` (
  `keyword_id` int(11) NOT NULL,
  `travel_plan_id` int(11) NOT NULL,
  PRIMARY KEY (`keyword_id`,`travel_plan_id`),
  KEY `FKfdxqqcrfovdj1q1yp3pf66gd3` (`travel_plan_id`),
  CONSTRAINT `FK775x92pdfs9srqwakfndncixv` FOREIGN KEY (`keyword_id`) REFERENCES `keywords` (`keyword_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FKfdxqqcrfovdj1q1yp3pf66gd3` FOREIGN KEY (`travel_plan_id`) REFERENCES `travel_plans` (`travel_plan_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travel_plan_keywords`
--

LOCK TABLES `travel_plan_keywords` WRITE;
/*!40000 ALTER TABLE `travel_plan_keywords` DISABLE KEYS */;
INSERT INTO `travel_plan_keywords` VALUES (8,103),(12,103),(5,104),(6,104),(11,104),(8,105),(11,105),(5,106),(6,106),(11,106),(3,107),(4,107),(4,108),(11,108),(13,108),(3,114),(10,114),(4,115),(3,116),(10,116),(8,117),(4,118),(6,118),(3,119),(4,119),(1,120),(4,120),(3,121),(4,121),(9,121),(3,122),(4,122),(3,123),(4,123);
/*!40000 ALTER TABLE `travel_plan_keywords` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21 10:13:23
