-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: i12c204.p.ssafy.io    Database: ukkikki
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members` (
  `member_id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` datetime(6) NOT NULL,
  `delete_time` datetime(6) DEFAULT NULL,
  `provider` varchar(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(64) NOT NULL,
  `profile_image_url` varchar(2000) NOT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members`
--

LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
INSERT INTO `members` VALUES (44,'2025-02-21 03:40:08.348143','2025-02-21 03:40:08.348143','','김준석','junseok@naver.com','$2a$10$DOcWDkhrPwDUCcaa55S7Re8d74iHNq2LewTWGXxeFtbaf24ti1l1q',''),(45,'2025-02-21 03:40:35.896013','2025-02-21 03:40:35.896013','','정규현','kyuhyeon@naver.com','$2a$10$ShWVeJEDbOLNkTYv.69tG.mvtNYl9WEayouWEdGrJe0zxl7Lz2OF.',''),(46,'2025-02-21 03:40:39.999054','2025-02-21 03:40:39.999054','','김영준','yeongjun@naver.com','$2a$10$nr3ejvtFzAdvLAeYi0wTKuYubjplmPz0vO2Sbm8jMp539fLpffksq',''),(47,'2025-02-21 03:41:00.193754','2025-02-21 03:41:00.193754','','박주현','juhyeon@naver.com','$2a$10$VoH4nIVM45wxACYGb9NZx.a.Hu8mkS0Ayw4w.UN89.BnwN1jN.uie',''),(48,'2025-02-21 03:41:17.102255','2025-02-21 03:41:17.102255','','허인주','inju@naver.com','$2a$10$ZSdCucq6qPq6wcxK4qs5au58g./Xw5JLKn73.sv.A5wX9jzXfBht.',''),(49,'2025-02-21 03:41:53.583272','2025-02-21 03:41:53.583272','','신승아','seunga@naver.com','$2a$10$LB/dVfg8LXyaN88u/QXoxO2fqmXWGfYaTf6VfZ0Nfz9iJ/fs1qdlK',''),(50,'2025-02-21 03:42:39.548439','2025-02-21 03:42:39.548439','','송창현','changhyeon@naver.com','$2a$10$LGNIoMJHn3SOHSGeXnXNwu3pOxXpDLIt8cY43FYIXU3FnKlXkdHLu',''),(51,'2025-02-21 03:45:49.065135','2025-02-21 03:45:49.065135','','최모두','modutour@modutour.co.kr','$2a$10$8djMrrlDdluvEH2ZfVOG6OTm7ozgFZt/T2KWTzbKxf94S5AJhWeqa',''),(52,'2025-02-21 03:56:24.092420','2025-02-21 03:56:24.092420','kakao','juhyeon','ashley0739@naver.com','','http://img1.kakaocdn.net/thumb/R640x640.q70/?fname=http://t1.kakaocdn.net/account_images/default_profile.jpeg'),(53,'2025-02-21 04:09:30.399689','2025-02-21 04:09:30.399689','','송창현','alslvls1995@naver.com','$2a$10$rbWUTVsVGQkhUGgcHhPQBOP20xJcgYbWuyHbrxnSkxtcdFuuWlrty',''),(54,'2025-02-21 08:37:02.003187','2025-02-21 08:37:02.003187','kakao','정규현','wjdrbgus8167@naver.com','','http://img1.kakaocdn.net/thumb/R640x640.q70/?fname=http://t1.kakaocdn.net/account_images/default_profile.jpeg'),(55,'2025-02-21 09:38:19.627865','2025-02-21 09:38:19.627865','kakao','신승아','tls001217@naver.com','','http://k.kakaocdn.net/dn/zp60Y/btsMcsvo6gT/lKYgaJHhBZFGAuFkrxDhM0/img_640x640.jpg');
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21 10:13:21
